from tkinter import  Tk, Canvas, PhotoImage, Button
import pandas as pd
import random
BACKGROUND_COLOR = "#B1DDC6"
current_card ={}
to_learn ={}

try:
    data = pd.read_csv(r"C:\Users\dxuxa\PycharmProjects\FlashCard\data\words_to_lean.csv")
except FileNotFoundError:
    original_data = pd.read_csv(r"C:\Users\dxuxa\PycharmProjects\FlashCard\data\french_words.csv")
    to_learn = original_data.to_dict(orient="records")
else:
    to_learn = data.to_dict(orient="records")


def next_card():
    global flip_timer
    global current_card
    global random_french_word
    window.after_cancel(flip_timer)
    current_card = random.choice(to_learn)
    canvas.itemconfig(title, text= "French")
    canvas.itemconfig(word, text=current_card["French"])
    canvas.itemconfig(card_background, image=front_image)
    flip_timer = window.after(3000, flip)

def is_known():
    to_learn.remove(current_card)
    data = pd.DataFrame(to_learn)
    data.to_csv(r"C:\Users\dxuxa\PycharmProjects\FlashCard\data\words_to_lean.csv")
    next_card()


def flip():

    canvas.itemconfig(title, text="English")
    canvas.itemconfig(word, text=current_card["English"])
    canvas.itemconfig(card_background, image=back_image)


window = Tk()


window.config(bg=BACKGROUND_COLOR)
window.config(padx=50, pady=50)
canvas = Canvas(width=800, height= 525, bg=BACKGROUND_COLOR, highlightthickness=0)
front_image = PhotoImage(file =r"C:\Users\dxuxa\PycharmProjects\FlashCard\images\card_front.png" )
card_background = canvas.create_image(400, 270, image = front_image)
canvas.grid(column=1, row=1, columnspan = 2)
flip_timer = window.after(3000, func=flip)


title = canvas.create_text(400, 150, text="", font=("Arial",30, "normal"))
word = canvas.create_text(400, 300, text="", font=("Arial",30, "bold"))

wrong_image = PhotoImage(file = r"C:\Users\dxuxa\PycharmProjects\FlashCard\images\wrong.png")
wrong_button = Button(image = wrong_image, highlightthickness=0, command=next_card)
wrong_button.grid(column=1, row=2)

right_image = PhotoImage(file = r"C:\Users\dxuxa\PycharmProjects\FlashCard\images\right.png")
right_button = Button(image = right_image, highlightthickness=0, command=is_known)
right_button.grid(column=2, row=2)
back_image = PhotoImage(file=r"C:\Users\dxuxa\PycharmProjects\FlashCard\images\card_back.png")

next_card()

window.mainloop()